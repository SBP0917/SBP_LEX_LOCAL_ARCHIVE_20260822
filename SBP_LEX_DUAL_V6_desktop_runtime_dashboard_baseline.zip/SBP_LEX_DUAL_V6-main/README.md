# SBP_LEX_DUAL_V6 — V1 Canonical Runtime

V1 canonical runtime-ready baseline.

## Active V1 topology

```text
APK
→ Connector Fabric
→ Canonical Runtime
→ Pipeline A / Pipeline B
→ Parity / Convergence
→ Governance Validation
→ Execution Admissibility
→ Audit + Observability
```

## Run locally

```bash
python3 main.py
```

## Run replay check

```bash
python3 main.py replay
```

## Run local API server

```bash
python3 main.py server 8000
```

## API endpoints

```text
GET  /health
GET  /runtime/status
GET  /runtime/events?after=<sequence>
POST /runtime/traverse
POST /runtime/replay
POST /connector/build-envelope
POST /connector/envelope
GET  /connector/checkpoints
```

## V1 rule

The APK is observational and orchestration-oriented only.

Execution authority exists only inside the canonical runtime.

---

## Desktop Runtime Dashboard

Start the local runtime API:

```bash
python3 main.py server
```

Open the desktop operator dashboard:

```text
http://127.0.0.1:8000/dashboard
```

The dashboard provides:

- runtime health
- traversal events
- dual adaptive deterministic pipeline visibility
- parity / convergence status
- execution decision
- audit / replay status
- controlled test request panel
- JSON export for latest runtime snapshot, replay ledger, and traversal events

Authority remains inside the canonical runtime. The dashboard is an operator interface only.
